Page({
  data: {
    time: ''
  },

  onLoad() {
    this.updateTime()
  },

  updateTime() {
    const now = new Date()
    const time = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`
    this.setData({ time })
  },

  openSimulator() {
    wx.navigateTo({
      url: '/pages/webview/webview',
      success: (res) => {
        console.log('页面跳转成功')
      },
      fail: (err) => {
        console.error('页面跳转失败', err)
        wx.showToast({
          title: '跳转失败',
          icon: 'none'
        })
      }
    })
  }
})