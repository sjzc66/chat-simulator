Page({
  data: {
    url: 'http://localhost:3000'
  },
  
  onLoad() {
    console.log('webview页面加载，URL:', this.data.url)
  },

  onError(e) {
    console.error('web-view加载错误:', e.detail)
    wx.showToast({
      title: '加载失败',
      icon: 'none'
    })
  }
})