class ChatSimulator {
    constructor() {
        this.initState();
        this.addDefaultUsers();
        this.initializeEventListeners();
        this.updateUI();
    }

    initState() {
        this.state = {
            carrier: '中国移动',
            networkType: 'Wifi',
            battery: 65,
            users: [],
            messages: [],
            currentUser: null,
            unreadCount: 5,
            phoneTime: '21:07'  // 添加时间状态
        };
    }

    addDefaultUsers() {
        const admin = {
            id: Date.now(),
            name: '本人',
            isAdmin: true,
            avatar: '/resources/avatars/avatar_1.svg'
        };
        
        const otherUser = {
            id: Date.now() + 1,
            name: '其他人',
            isAdmin: false,
            avatar: '/resources/avatars/avatar_2.svg'
        };

        this.state.users = [admin, otherUser];
        this.state.currentUser = admin;
    }

    initializeEventListeners() {
        // 标签切换
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.state.currentTab = btn.dataset.tab;
                this.updateUI();
            });
        });

        // 设置面板
        const settingsMap = {
            carrier: 'change',
            networkType: 'change',
            battery: 'input',
            unreadCount: 'input'
        };

        Object.entries(settingsMap).forEach(([id, event]) => {
            const element = document.getElementById(id);
            if (element) {
                element.addEventListener(event, (e) => {
                    this.state[id] = e.target.value;
                    this.updateUI();
                });
            }
        });

        // 消息操作
        const actions = {
            addTextMsg: () => this.addMessage(),
            clearChat: () => this.clearChat(),
            generateImage: () => this.generateImage(),
            addUser: () => this.addUser()
        };

        Object.entries(actions).forEach(([id, handler]) => {
            const element = document.getElementById(id);
            if (element) {
                element.addEventListener('click', handler.bind(this));
            }
        });
    }

    updateUI() {
        this.updateStatusBar();
        this.updateTabs();
        this.updateUnreadCount();
        this.updateUserList();
    }

    updateStatusBar() {
        const left = document.querySelector('.status-bar .left');
        const right = document.querySelector('.status-bar .right');
        
        if (left && right) {
            left.textContent = `${this.state.carrier} 21:07`;
            right.textContent = `信号 ${this.state.networkType} ${this.state.battery}%`;
        }
    }

    updateTabs() {
        // 更新标签按钮状态
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === this.state.currentTab);
        });

        // 更新内容显示
        const appearanceSettings = document.getElementById('appearanceSettings');
        const chatSettings = document.getElementById('chatSettings');
        
        if (appearanceSettings && chatSettings) {
            appearanceSettings.style.display = this.state.currentTab === 'appearance' ? 'block' : 'none';
            chatSettings.style.display = this.state.currentTab === 'chat' ? 'block' : 'none';
        }
    }

    updateUnreadCount() {
        const unreadCountElement = document.querySelector('.unread-count');
        if (unreadCountElement) {
            unreadCountElement.textContent = this.state.unreadCount;
        }
    }

    updateUserList() {
        const chatSettings = document.getElementById('chatSettings');
        if (!chatSettings) return;

        const userList = document.createElement('div');
        userList.className = 'user-list';
        userList.innerHTML = `
            <h3>当前用户列表：</h3>
            ${this.state.users.map(user => `
                <div class="user-item ${user.id === this.state.currentUser?.id ? 'active' : ''}" 
                     data-user-id="${user.id}">
                    <img src="${user.avatar}" alt="头像" class="user-avatar">
                    <span>${user.name}</span>
                    <span>${user.isAdmin ? '(主人)' : ''}</span>
                </div>
            `).join('')}
        `;

        // 绑定用户选择事件
        userList.querySelectorAll('.user-item').forEach(item => {
            item.addEventListener('click', () => {
                const userId = parseInt(item.dataset.userId);
                this.state.currentUser = this.state.users.find(u => u.id === userId);
                this.updateUI();
            });
        });

        // 替换现有用户列表
        const oldUserList = chatSettings.querySelector('.user-list');
        if (oldUserList) {
            oldUserList.replaceWith(userList);
        } else {
            const messageInput = chatSettings.querySelector('.user-input');
            messageInput?.parentNode.insertBefore(userList, messageInput);
        }
    }

    addUser() {
        const user = {
            id: Date.now(),
            name: `用户${this.state.users.length + 1}`,
            isAdmin: false,
            avatar: `/resources/avatars/avatar_${Math.floor(Math.random() * 20) + 1}.svg`
        };
        
        this.state.users.push(user);
        this.state.currentUser = user;
        this.updateUI();
    }

    addMessage() {
        if (!this.validateMessageInput()) return;

        const content = document.getElementById('messageContent').value;
        const message = {
            id: Date.now(),
            content,
            userId: this.state.currentUser.id,
            timestamp: new Date().toLocaleTimeString()
        };

        this.state.messages.push(message);
        this.renderMessage(message);
        document.getElementById('messageContent').value = '';
    }

    validateMessageInput() {
        if (!this.state.currentUser) {
            alert('请先选择发送消息的用户');
            return false;
        }

        const content = document.getElementById('messageContent').value;
        if (!content) {
            alert('请输入消息内容');
            return false;
        }
        return true;
    }

    renderMessage(message) {
        const user = this.state.users.find(u => u.id === message.userId);
        const container = document.createElement('div');
        container.className = `message ${user.isAdmin ? 'sent' : ''}`;
        
        container.innerHTML = `
            <img src="${user.avatar}" class="avatar">
            <div class="content">${message.content}</div>
        `;
        
        document.getElementById('chatContainer')?.appendChild(container);
    }

    clearChat() {
        this.state.messages = [];
        const chatContainer = document.getElementById('chatContainer');
        if (chatContainer) {
            chatContainer.innerHTML = '';
        }
    }

    async generateImage() {
        try {
            const chatPreview = document.querySelector('.chat-preview');
            if (!chatPreview) return;

            const canvas = await html2canvas(chatPreview);
            const link = document.createElement('a');
            link.download = 'chat.png';
            link.href = canvas.toDataURL();
            link.click();
        } catch (error) {
            console.error('生成图片失败:', error);
            alert('生成图片失败');
        }
    }
}

// 页面加载完成后初始化
window.addEventListener('DOMContentLoaded', () => {
    window.chatSimulator = new ChatSimulator();
});